<?php
session_start();
include 'config.php';

header('Content-Type: text/html; charset=utf-8');

// Создаем подключение
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверяем подключение
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Получаем данные из формы
$instagram_username = $_POST['username'];
$quantity = (int)$_POST['quantity'];
$email = $_POST['email'];
$total_price = $quantity * 0.01; // Цена за подписчика (0.1 сомон)

// Подготавливаем SQL-запрос для вставки данных
$stmt = $conn->prepare("INSERT INTO orders (username, quantity, email, total_price) VALUES (?, ?, ?, ?)");
$stmt->bind_param("sisd", $instagram_username, $quantity, $email, $total_price);

// Выполняем запрос
$total_price = $quantity * 0.01; // Цена за подписчика (0.1 сомон)
if ($stmt->execute() === TRUE) {
    echo "
    <div style='text-align: center; font-family: Arial, sans-serif;'>
        <h2 style='color: #4CAF50;'>После оплаты заказ будет принят!</h2>
        <p style='font-size: 22px;'>Сумма к оплате: $total_price сомони</p>
        <p style='font-size: 18px;'>Номер карты Dushanbe City</p>
        <h1 style='color: #FF5722;'>9762 0000 1628 2641</h1>
        <p style='font-size: 18px;'>Накрутка будет доставлен вам в течение максимум 6 часов после оплаты</p>
        <p style='font-size: 25px;' id='timer'>Переход на главную страницу через 60 секунд</p>
    </div>
    <script type='text/javascript' src='countdown.js'></script>
    ";
} else {
    echo "<div style='text-align: center; font-family: Arial, sans-serif; color: #FF0000;'><h2>Ошибка: " . $stmt->error . "</h2></div>";
}

// Закрываем соединение
$stmt->close();
$conn->close();
?>