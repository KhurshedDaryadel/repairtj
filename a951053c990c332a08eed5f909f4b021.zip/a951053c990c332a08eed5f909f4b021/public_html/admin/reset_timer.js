let timeout;

function resetTimer() {
  clearTimeout(timeout);
  timeout = setTimeout(logout, 180000); // 1 минута = 60000 миллисекунд
}

function logout() {
  window.location.href = 'logout.php';
}

window.onload = resetTimer;
window.onmousemove = resetTimer;
window.onkeypress = resetTimer;