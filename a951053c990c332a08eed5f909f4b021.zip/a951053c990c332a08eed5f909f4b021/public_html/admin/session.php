<?php
// session.php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php?error=Пожалуйста, сначала войдите в систему.");
    exit();
}
?>