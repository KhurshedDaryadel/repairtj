<?php
    session_start();
    session_unset();
    session_destroy();
    header("Location: index.php?message=Сессия истекла из-за неактивности.");
    exit();
?>