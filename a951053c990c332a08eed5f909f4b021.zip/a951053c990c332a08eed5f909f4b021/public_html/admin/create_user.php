<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <link rel="icon" href="img/login.ico" type="image/x-icon">
  <title>Создание пользователя</title>
  <link rel="stylesheet" type="text/css" href="css/login.css">
</head>
<body>
  <form id="slick-login" action="new_user.php" method="POST">
    <div class="input-group">
            <input type="text" name="username" required>
            <label for="username">Имя пользователя</label>
        </div>
        <div class="input-group">
            <input type="password" name="password" required>
            <label for="password">Пароль</label>
        </div>
        <div class="input-group">
            <input type="password" name="confirm_password" required>
            <label for="confirm_password">Повторите пароль</label>
        </div>
        <div class="input-group">
            <input type="submit" value="Создать пользователя">
      </div>
  </form>
  <?php
    if (isset($_GET['message'])) {
        echo "<p style='color:green;'>" . htmlspecialchars($_GET['message']) . "</p>";
    }
  ?>
</body>
</html>