<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/login.ico" type="image/x-icon">
    <title>daryadel.ru | login</title>
    <link rel="stylesheet" href="css/login.css">
</head>

<body>
    <form id="slick-login" action="login.php" method="POST">

        <?php
            if (isset($_GET['error'])) {
                echo "<div class='popup' id='errorPopup'><h2>Сообщение!</h2><p>" . htmlspecialchars($_GET['error']) . "</p><button type='button' onclick='closePopup()'>Закрыть</button></div>";
            }
        ?>

        <div class="input-group">
            <input type="text" name="username" required>
            <label for="username">Имя пользователя</label>
        </div>
        <div class="input-group">
            <input type="password" name="password" required>
            <label for="password">Пароль</label>
        </div>
        <div class="input-group">
            <input type="submit" value="ВОЙТИ">
        </div>
    </form>

    <script>
        // Функция отображения всплывающего окна
        function showPopup() {
        document.getElementById('errorPopup').style.display = 'block';
        }

        // Функция скрытия всплывающего окна
        function closePopup() {
        document.getElementById('errorPopup').style.display = 'none';
        }

        // Показать всплывающее окно, если произошла ошибка
        <?php if (isset($_GET['error'])) { ?>
            showPopup();
        <?php } ?>
    </script>

</body>

</html>