<?php
// user_operations.php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_password'])) {
        $username = $_POST['username'];
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
        $stmt->bind_param("ss", $new_password, $username);

        if ($stmt->execute()) {
            echo "<p style='color:green;'>Пароль успешно обновлен!</p>";
        } else {
            echo "<p style='color:red;'>Ошибка при обновлении пароля: " . $conn->error . "</p>";
        }
    }

    if (isset($_POST['delete_user'])) {
        $username = $_POST['delete_username'];

        $stmt = $conn->prepare("DELETE FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);

        if ($stmt->execute()) {
            echo "<p style='color:green;'>Пользователь успешно удален!</p>";
        } else {
            echo "<p style='color:red;'>Ошибка при удалении пользователя: " . $conn->error . "</p>";
        }

        // Проверьте, остались ли пользователи
        $result = $conn->query("SELECT username FROM users");
        if ($result->num_rows == 0) {
            // Перенаправить на create_user.php если не осталось пользователей
            header("Location: create_user.php");
            exit();
        }
    }
}

// Получить всех пользователей
$result = $conn->query("SELECT username FROM users");
?>