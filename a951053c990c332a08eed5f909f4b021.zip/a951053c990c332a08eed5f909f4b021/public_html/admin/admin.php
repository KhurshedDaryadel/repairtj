<?php
  include 'session.php';
  include 'page_visits.php';
  include 'user_operations.php';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <link rel="icon" href="img/admin.ico" type="image/x-icon">
  <title>daryadel.ru | Admin Panel</title>
  <link rel="stylesheet" type="text/css" href="css/admin.css">
  <script type="text/javascript" src="reset_timer.js"></script>
</head>
<body>
  <div class="top">
      <h1>Панель администратора</h1>
      <a href="logout.php">Выйти</a>
  </div>
  <p>Количество посещений страницы: <?php echo $visit_count; ?></p>
  <form method="POST">
    <label for="username">Выберите пользователя:</label>
    <select name="username" id="username">
      <?php while ($row = $result->fetch_assoc()): ?>
        <option value="<?php echo htmlspecialchars($row['username']); ?>">
          <?php echo htmlspecialchars($row['username']); ?>
        </option>
      <?php endwhile; ?>
    </select>
    <label for="new_password">Новый пароль:</label>
    <input type="password" name="new_password" id="new_password" required>
    <input type="submit" name="update_password" value="Обновить пароль">
  </form>

  <form method="POST">
    <label for="delete_username">Выберите пользователя для удаления:</label>
    <select name="delete_username" id="delete_username">
      <?php
        // Получаем всех пользователей снова, чтобы показать в селекте для удаления
        $result = $conn->query("SELECT username FROM users");
        while ($row = $result->fetch_assoc()): 
      ?>
        <option value="<?php echo htmlspecialchars($row['username']); ?>">
          <?php echo htmlspecialchars($row['username']); ?>
        </option>
      <?php endwhile; ?>
    </select>
    <input type="submit" name="delete_user" value="Удалить пользователя">
  </form>
  
  <?php
    require_once('admin_orders.php');
    require_once('admin_curses.php');
    require_once('admin_views.php');
  ?>

</body>
</html>