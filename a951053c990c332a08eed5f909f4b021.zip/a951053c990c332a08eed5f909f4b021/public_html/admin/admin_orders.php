<?php
    $servername = "localhost";
    $username = "c92200n1_khz"; // Укажите вашего пользователя БД
    $password = "c92200n1_1411"; // Укажите пароль БД
    $dbname = "c92200n1_khz";

// Создаем подключение
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверяем подключение
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Удаление заказа
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    $conn->query("DELETE FROM orders WHERE id = $delete_id");
    header("Location: admin.php");
    exit();
}

// Получаем данные из таблицы
$result = $conn->query("SELECT * FROM orders ORDER BY created_at ASC");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ - Заказы</title>
    <link rel="stylesheet" href="css/a.css">
</head>
<body>
    <h1>Список Подписчики</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Instagram</th>
            <th>Количество</th>
            <th>Email</th>
            <th>Сумма</th>
            <th>Дата</th>
            <th>Действие</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td><?php echo htmlspecialchars($row['email']); ?></td>
            <td><?php echo $row['total_price']; ?> Сомон</td>
            <td><?php echo $row['created_at']; ?></td>
            <td><a href="admin.php?delete_id=<?php echo $row['id']; ?>" onclick="return confirm('Удалить заказ?');">Удалить</a></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
<?php
$conn->close();
?>