<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        include 'config.php';

        $username = $_POST['username'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if ($password !== $confirm_password) {
            $message = "Пароли не совпадают.";
            header("Location: create_user.php?message=" . urlencode($message));
            exit();
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Проверка существования пользователя
            $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $message = "Пользователь с таким логином уже существует.";
                header("Location: create_user.php?message=" . urlencode($message));
                exit();
            } else {
                // Создание нового пользователя
                $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
                $stmt->bind_param("ss", $username, $hashed_password);

                if ($stmt->execute()) {
                    $message = "Пользователь успешно создан!";
                    header("Location: create_user.php?message=" . urlencode($message));
                    exit();
                } else {
                    $message = "Ошибка при создании пользователя: " . $conn->error;
                    header("Location: create_user.php?message=" . urlencode($message));
                    exit();
                }
            }
        }
    }
?>