<?php
    $servername = "localhost";
    $username = "c92200n1_khz"; // Укажите вашего пользователя БД
    $password = "c92200n1_1411"; // Укажите пароль БД
    $dbname = "c92200n1_khz";

    // Создать соединение
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Проверьте соединение
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>