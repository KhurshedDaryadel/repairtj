<?php
    // page_visits.php
    include 'config.php';

    // Инициализируйте счетчик посещений страниц в базе данных, если его нет
    $result = $conn->query("SELECT * FROM page_visits WHERE id = 1");
    if ($result->num_rows == 0) {
        $conn->query("INSERT INTO page_visits (visit_count) VALUES (0)");
    }

    // Увеличить счетчик посещений страницы
    $conn->query("UPDATE page_visits SET visit_count = visit_count + 1 WHERE id = 1");

    // Узнать текущее количество посещений
    $result = $conn->query("SELECT visit_count FROM page_visits WHERE id = 1");
    $row = $result->fetch_assoc();
    $visit_count = $row['visit_count'];
?>