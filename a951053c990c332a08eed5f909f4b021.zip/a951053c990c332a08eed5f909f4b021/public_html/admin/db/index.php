<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Admin</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
  <style>
    
  </style>
</head>
<body>

  <form id="slick-login" action="login.php" method="POST">
    <?php
      if (isset($_GET['error'])) {
        echo "<div class='popup' id='errorPopup'><h2>Сообщение!</h2><p>" . htmlspecialchars($_GET['error']) . "</p><button type='button' onclick='closePopup()'>Закрыть</button></div>";
      }
    ?>
    <label for="username">Логин:</label>
    <input type="text" name="username" class="login" placeholder="Логин">
    <label for="password">Пароль:</label>
    <input type="password" name="password" class="pass" placeholder="Пароль">
    <input type="submit" value="ВОЙТИ">
  </form>

  <script>
    // Function to show the popup
    function showPopup() {
      document.getElementById('errorPopup').style.display = 'block';
    }

    // Function to hide the popup
    function closePopup() {
      document.getElementById('errorPopup').style.display = 'none';
    }

    // Show the popup if there's an error
    <?php if (isset($_GET['error'])) { ?>
      showPopup();
    <?php } ?>
  </script>
</body>
</html>
