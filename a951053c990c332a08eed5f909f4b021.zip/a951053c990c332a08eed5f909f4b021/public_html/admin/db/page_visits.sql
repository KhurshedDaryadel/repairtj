CREATE TABLE page_visits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    visit_count INT DEFAULT 0
);