<?php
    $servername = "localhost";
    $username = "c92200n1_khz"; // Укажите вашего пользователя БД
    $password = "c92200n1_1411"; // Укажите пароль БД
    $dbname = "c92200n1_khz";

// Подключение к базе данных
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка подключения
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Удаление заказа
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM likes_orders WHERE id=$id");
    header("Location: admin.php");
    exit();
}

// Получение заказов
$result = $conn->query("SELECT * FROM likes_orders");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель</title>
    <link rel="stylesheet" href="css/a.css">
</head>
<body>
    <h1>Список Лайки</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Имя пользователя</th>
            <th>Ссылка</th>
            <th>Количество</th>
            <th>Email</th>
            <th>Сумма</th>
            <th>Дата заказа</th>
            <th>Действие</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['username']; ?></td>
                <td><a href="<?php echo $row['link']; ?>" target="_blank">Ссылка</a></td>
                <td><?php echo $row['quantity']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['total_price']; ?> Сомон</td>
                <td><?php echo $row['created_at']; ?></td>
                <td><a href="admin.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Удалить этот заказ?');">Удалить</a></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

<?php $conn->close(); ?>