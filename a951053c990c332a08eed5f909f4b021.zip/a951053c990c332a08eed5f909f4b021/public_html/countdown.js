var countdown = 60;
var timer = document.getElementById('timer');
setInterval(function(){
    countdown--;
    timer.innerHTML = 'Переход на главную страницу через ' + countdown + ' секунд';
    if(countdown <= 0) {
        window.location.href = 'index.php'; // Замените 'index.php' на URL главной страницы
    }
}, 1000); // Обновление каждую секунду