<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Накрутка инстаграм лайков, подписчиков, просмотров</title>
    <link rel="stylesheet" href="css/styles.css">
    <script>
        function updatePrice() {
            let quantity = document.getElementById('quantity').value;
            let pricePerItem = 0.003;
            let totalPrice = quantity * pricePerItem;
            document.getElementById('total-price').textContent = totalPrice.toFixed(2);
        }
    </script>
</head>
<body>
    <div class="order-container">
        <h1>Лайки живые</h1>
        <p class="subtitle">Накрутка инстаграм подписчиков, лайков, просмотров.</p>
        
        <form action="process_curses.php" method="POST">
            <label for="username">Имя пользователь Instagram</label>
            <input type="text" id="username" name="username" required>

            <label for="link">Ссылка видео от Instagram</label>
            <input type="text" id="link" name="link" required>
            
            <label for="quantity">Количество лайки</label>
            <input type="number" id="quantity" name="quantity" min="100" max="100000000" required oninput="updatePrice()">
            
            <label for="email">Ваш E-Mail</label>
            <input type="email" id="email" name="email" required>
            
            <p>Сумма: <span id="total-price">0</span> Сомон</p>
            
            <button type="submit">Заказать</button>
        </form>
    </div>
</body>
</html>