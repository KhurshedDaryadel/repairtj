<?php
session_start();
include 'config.php';

header('Content-Type: text/html; charset=utf-8');

// Подключение к базе данных
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка подключения
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Получение данных из формы
$username = $_POST['username'];
$link = $_POST['link'];
$quantity = $_POST['quantity'];
$email = $_POST['email'];
$pricePerItem = 0.002;
$total_price = $quantity * $pricePerItem;

// SQL-запрос для вставки данных
$sql = "INSERT INTO views_orders (username, link, quantity, email, total_price) 
        VALUES ('$username', '$link', '$quantity', '$email', '$total_price')";
        
$total_price = $quantity * 0.002; // Цена за подписчика (0.1 сомон)
if ($conn->query($sql) === TRUE) {
    echo "
    <div style='text-align: center; font-family: Arial, sans-serif;'>
        <h2 style='color: #4CAF50;'>После оплаты заказ будет принят!</h2>
        <p style='font-size: 22px;'>Сумма к оплате: $total_price сомони</p>
        <p style='font-size: 18px;'>Только первый раз попробовать бесплатно</p>
        <p style='font-size: 18px;'>Будет доставлен вам в течение 6 часов</p>
        <p style='font-size: 18px;'>Номер карты Dushanbe City</p>
        <h2 style='color: #FF5722;'>9762 0000 1628 2641</h2>
        <p style='font-size: 18px;'>Накрутка будет доставлен вам в течение максимум 6 часов после оплаты</p>
        <p style='font-size: 25px;' id='timer'>Переход на главную страницу через 60 секунд</p>
    </div>
    <script type='text/javascript' src='countdown.js'></script>
    ";
} else {
    echo "<div style='text-align: center; font-family: Arial, sans-serif; color: #FF0000;'><h2>Ошибка: " . $conn->error . "</h2></div>";
}

$conn->close();
?>